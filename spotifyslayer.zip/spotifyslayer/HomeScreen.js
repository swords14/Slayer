import React, { useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, ScrollView, FlatList, Animated } from 'react-native';
import { SearchBar } from 'react-native-elements';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { LinearGradient } from 'expo-linear-gradient';

const Header = () => (
  <LinearGradient
    colors={['#2b5876', '#4e4376']}
    start={{ x: 0, y: 0 }}
    end={{ x: 1, y: 1 }}
    style={styles.header}>
    <Image source={{ uri: 'https://example.com/logo.png' }} style={styles.logo} />
  </LinearGradient>
);

const FeaturedItem = ({ title, imageUri, onPress, animation }) => (
  <Animated.View style={[styles.featuredItem, animation]}>
    <TouchableOpacity onPress={onPress}>
      <Image source={{ uri: imageUri }} style={styles.featuredImage} />
      <Text style={styles.featuredTitle}>{title}</Text>
    </TouchableOpacity>
  </Animated.View>
);

const HomeScreen = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const navigation = useNavigation();

  const handleLibraryPress = () => {
    navigation.navigate('MusicLibraryScreen');
  };

  const handleHomePress = () => {
    // Navegar para a tela de início
  };

  const handleSearchPress = () => {
    // Navegar para a tela de pesquisa
  };

  const featuredAlbums = [
    { id: 1, title: 'Álbum em Destaque 1', imageUri: 'https://p2.trrsf.com/image/fget/cf/940/0/images.terra.com/2019/01/07/capas-de-discos-ciencia-int01-pinkfloyd.jpg' },
    { id: 2, title: 'Álbum em Destaque 2', imageUri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQmvFnANZUxCZaEbW9Q34USbEED3C_K2eE66Q&usqp=CAU' },
    { id: 3, title: 'Álbum em Destaque 3', imageUri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ6tgkQ7u21P49YwXiZivZFyiXwLP71ix6oEYwi1xotc3YV7I70IbbvusBVKDqKg2awixw&usqp=CAU' },
  ];

  const featuredArtists = [
    { id: 1, title: 'Artista em Destaque 1', imageUri: 'https://edm.com/.image/t_share/MTY0MTA5NTM5MTI4Mzg2ODM0/rival.jpg' },
    { id: 2, title: 'Artista em Destaque 2', imageUri: 'https://viberatecdn.blob.core.windows.net/entity/artist/shometyle-zTMNA' },
    { id: 3, title: 'Artista em Destaque 3', imageUri: 'https://thefader-res.cloudinary.com/private_images/w_1440,c_limit,f_auto,q_auto:best/FADER-Mix-Suicideyear_nhthy5/photo-by-dan-wilton.jpg' },
  ];

  const featuredPlaylists = [
    { id: 1, title: 'Playlist em Destaque 1', imageUri: 'https://i.scdn.co/image/ab6761610000e5eb958c735a23111c6c305d8cce' },
    { id: 2, title: 'Playlist em Destaque 2', imageUri: 'https://i.scdn.co/image/ab67616d00001e02e8d02411be4b3e2ee811980a' },
    { id: 3, title: 'Playlist em Destaque 3', imageUri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTPKFw80GnzShr2PgZqe0eVqT29ZT8sAj0C8RosJhU3OuFpuxovyrTQqwtzZgwofgEO4ec&usqp=CAU' },
  ];

  const [animations, setAnimations] = useState({});

  const animateItem = (itemId) => {
    Animated.sequence([
      Animated.timing(animations[itemId], {
        toValue: 1,
        duration: 500,
        useNativeDriver: true,
      }),
      Animated.timing(animations[itemId], {
        toValue: 0,
        duration: 500,
        useNativeDriver: true,
      }),
    ]).start();
  };

  return (
    <ScrollView style={styles.container}>
      <Header />
      <SearchBar
        placeholder="Pesquisar..."
        onChangeText={setSearchQuery}
        value={searchQuery}
        containerStyle={styles.searchBar}
        inputContainerStyle={styles.searchInput}
      />
      <View style={styles.content}>
        <Text style={styles.sectionTitle}>Álbuns em Destaque</Text>
        <FlatList
          data={featuredAlbums}
          keyExtractor={(item) => item.id.toString()}
          horizontal
          showsHorizontalScrollIndicator={false}
          renderItem={({ item }) => (
            <FeaturedItem
              title={item.title}
              imageUri={item.imageUri}
              onPress={() => {
                animateItem(item.id);
                navigation.navigate('AlbumDetails', { album: item });
              }}
              animation={{
                transform: [
                  {
                    scale: animations[item.id] || new Animated.Value(1),
                  },
                ],
              }}
            />
          )}
        />

        <Text style={styles.sectionTitle}>Artistas em Destaque</Text>
        <FlatList
          data={featuredArtists}
          keyExtractor={(item) => item.id.toString()}
          horizontal
          showsHorizontalScrollIndicator={false}
          renderItem={({ item }) => (
            <FeaturedItem
              title={item.title}
              imageUri={item.imageUri}
              onPress={() => {
                animateItem(item.id);
                navigation.navigate('ArtistDetails', { artist: item });
              }}
              animation={{
                transform: [
                  {
                    scale: animations[item.id] || new Animated.Value(1),
                  },
                ],
              }}
            />
          )}
        />

        <Text style={styles.sectionTitle}>Playlists em Destaque</Text>
        <FlatList
          data={featuredPlaylists}
          keyExtractor={(item) => item.id.toString()}
          horizontal
          showsHorizontalScrollIndicator={false}
          renderItem={({ item }) => (
            <FeaturedItem
              title={item.title}
              imageUri={item.imageUri}
              onPress={() => {
                animateItem(item.id);
                navigation.navigate('PlaylistDetails', { playlist: item });
              }}
              animation={{
                transform: [
                  {
                    scale: animations[item.id] || new Animated.Value(1),
                  },
                ],
              }}
            />
          )}
        />
      </View>
      <View style={styles.navigation}>
        <TouchableOpacity style={styles.navigationButton} onPress={handleHomePress}>
          <LinearGradient
            colors={['#2b5876', '#4e4376']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={styles.navButtonGradient}>
            <Ionicons name="home" size={24} color="#fff" />
          </LinearGradient>
          <Text style={styles.navigationButtonText}>Início</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navigationButton} onPress={handleSearchPress}>
          <LinearGradient
            colors={['#2b5876', '#4e4376']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={styles.navButtonGradient}>
            <Ionicons name="search" size={24} color="#fff" />
          </LinearGradient>
          <Text style={styles.navigationButtonText}>Pesquisar</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navigationButton} onPress={handleLibraryPress}>
          <LinearGradient
            colors={['#2b5876', '#4e4376']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={styles.navButtonGradient}>
            <Ionicons name="library" size={24} color="#fff" />
          </LinearGradient>
          <Text style={styles.navigationButtonText}>Biblioteca</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    padding: 20,
    alignItems: 'center',
  },
  logo: {
    width: 150,
    height: 50,
    resizeMode: 'contain',
  },
  searchBar: {
    backgroundColor: '#f5f5f5',
    borderTopWidth: 0,
    borderBottomWidth: 0,
    padding: 0,
    marginHorizontal: 20,
    marginVertical: 10,
    borderRadius: 10,
    elevation: 5,
  },
  searchInput: {
    backgroundColor: '#fff',
  },
  content: {
    padding: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  featuredItem: {
    marginRight: 20,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  featuredImage: {
    width: 150,
    height: 150,
    borderRadius: 10,
  },
  featuredTitle: {
    marginTop: 5,
    fontSize: 14,
    textAlign: 'center',
  },
  navigation: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    backgroundColor: '#f5f5f5',
    paddingVertical: 10,
  },
  navigationButton: {
    alignItems: 'center',
  },
  navigationButtonText: {
    fontSize: 12,
    color: '#333',
  },
  navButtonGradient: {
    padding: 10,
    borderRadius: 20,
  },
});

export default HomeScreen;
