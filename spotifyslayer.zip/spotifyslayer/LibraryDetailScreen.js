import React from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, Animated, ScrollView } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';

const LibraryDetailScreen = ({ route, navigation }) => {
  const { libraryId } = route.params;

  const libraryDetails = {
    id: libraryId,
    title: 'Library Title',
    description: 'Description of the library.',
    imageUri: 'https://example.com/library-image.jpg',
    songsCount: 50,
    featuredArtists: ['Artist 1', 'Artist 2', 'Artist 3'],
  };

  const handlePlayMusic = () => {
    // Lógica para reproduzir música da biblioteca
  };

  const fadeAnim = React.useRef(new Animated.Value(0)).current;

  React.useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 1000,
      useNativeDriver: true,
    }).start();
  }, [fadeAnim]);

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <LinearGradient colors={['#FFD700', '#FFA500']} style={styles.background}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color="blue" />
        </TouchableOpacity>
        <Image source={{ uri: libraryDetails.imageUri }} style={styles.libraryImage} />
        <Text style={styles.libraryTitle}>{libraryDetails.title}</Text>
        <Text style={styles.libraryDescription}>{libraryDetails.description}</Text>
        <Text style={styles.libraryInfo}>Total Songs: {libraryDetails.songsCount}</Text>
        <Text style={styles.libraryInfo}>Featured Artists: {libraryDetails.featuredArtists.join(', ')}</Text>
        <TouchableOpacity onPress={handlePlayMusic} style={styles.playButton}>
          <Text style={styles.playButtonText}>Play Music</Text>
        </TouchableOpacity>
      </LinearGradient>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  background: {
    flex: 1,
    width: '100%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  backButton: {
    position: 'absolute',
    top: 20,
    left: 20,
  },
  libraryImage: {
    width: 200,
    height: 200,
    borderRadius: 10,
    marginBottom: 10,
  },
  libraryTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#333',
  },
  libraryDescription: {
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 10,
    color: '#666',
  },
  libraryInfo: {
    fontSize: 14,
    marginBottom: 5,
    color: '#999',
  },
  playButton: {
    backgroundColor: '#4CAF50',
    padding: 10,
    borderRadius: 5,
    marginTop: 20,
  },
  playButtonText: {
    color: '#FFF',
    fontSize: 16,
    textAlign: 'center',
  },
});

export default LibraryDetailScreen;