import 'react-native-gesture-handler';
import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, Modal, Linking, KeyboardAvoidingView, TouchableWithoutFeedback, Keyboard, Platform, Image } from 'react-native';
import { MaterialIcons, FontAwesome, Entypo } from '@expo/vector-icons';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

const Stack = createStackNavigator();

const LoginButton = ({ onClick }) => (
  <TouchableOpacity style={styles.loginButton} onPress={onClick}>
    <Text style={styles.loginButtonText}>Login</Text>
  </TouchableOpacity>
);

const FacebookLoginButton = ({ onClick }) => (
  <TouchableOpacity style={[styles.button, { backgroundColor: '#3b5998' }]} onPress={onClick}>
    <MaterialIcons name="facebook" size={24} color="#FFFFFF" />
    <Text style={[styles.buttonText, { color: '#FFFFFF' }]}>Facebook</Text>
  </TouchableOpacity>
);

const GoogleLoginButton = ({ onClick }) => (
  <TouchableOpacity style={[styles.button, { backgroundColor: '#DB4437' }]} onPress={onClick}>
    <FontAwesome name="google" size={24} color="#FFFFFF" />
    <Text style={[styles.buttonText, { color: '#FFFFFF' }]}>Google</Text>
  </TouchableOpacity>
);

const InstagramLoginButton = ({ onClick }) => (
  <TouchableOpacity style={[styles.button, { backgroundColor: '#E4405F' }]} onPress={onClick}>
    <Entypo name="instagram" size={24} color="#FFFFFF" />
    <Text style={[styles.buttonText, { color: '#FFFFFF' }]}>Instagram</Text>
  </TouchableOpacity>
);

const AppleLoginButton = ({ onClick }) => (
  <TouchableOpacity style={[styles.button, { backgroundColor: '#000000' }]} onPress={onClick}>
    <MaterialIcons name="apple" size={24} color="#FFFFFF" />
    <Text style={[styles.buttonText, { color: '#FFFFFF' }]}>Apple</Text>
  </TouchableOpacity>
);

const AppHeader = () => {
  return (
    <View style={styles.header}>
      <Image source={{ uri: 'https://i.imgur.com/I2tza65.png' }} style={styles.logo} />
    </View>
  );
};

const LoginScreen = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [modalVisible, setModalVisible] = useState(false);

  const handleLogin = () => {
    if (email.trim() === '' && password === '') {
      Alert.alert('Login bem-sucedido', 'Bem-vindo de volta!');
      navigation.navigate('HomeScreen'); // Navegar para a tela de HomeScreen
    } else {
      Alert.alert('Erro de Login', 'Credenciais inválidas. Por favor, tente novamente.');
    }
  };

  const handleFacebookLogin = () => {
    // Lógica de autenticação com Facebook
  };

  const handleGoogleLogin = () => {
    // Lógica de autenticação com Google
  };

  const handleInstagramLogin = () => {
    // Lógica de autenticação com Instagram
  };

  const handleAppleLogin = () => {
    // Lógica de autenticação com Apple
  };

  const openEmailApp = () => {
    Linking.openURL('mailto:suporte@exemplo.com?subject=Relatar Problema Técnico&body=Descreva o problema aqui...');
  };

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === "ios" ? "height" : null} keyboardVerticalOffset={-500}>
      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
        <View style={styles.inner}>
          <AppHeader />
          <TextInput
            style={styles.input}
            placeholder="Email"
            value={email}
            onChangeText={setEmail}
            autoCapitalize="none"
            keyboardType="email-address"
          />
          <TextInput
            style={styles.input}
            placeholder="Senha"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
          />
          <LoginButton onClick={handleLogin} />
          <View style={styles.buttonContainer}>
            <FacebookLoginButton onClick={handleFacebookLogin} />
            <GoogleLoginButton onClick={handleGoogleLogin} />
            <InstagramLoginButton onClick={handleInstagramLogin} />
            <AppleLoginButton onClick={handleAppleLogin} />
          </View>
          <TouchableOpacity style={styles.helpButton} onPress={() => setModalVisible(true)}>
            <MaterialIcons name="help" size={24} color="#FF6347" />
            <Text style={styles.helpButtonText}> Precisa de Ajuda? </Text>
          </TouchableOpacity>
        </View>
      </TouchableWithoutFeedback>
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => {
          setModalVisible(false);
        }}
      >
        <View style={styles.modalContainer}>
          <Text style={styles.modalText}>Precisa de Ajuda?</Text>
          <Text style={styles.modalInstructions}>Entre em contato conosco para obter suporte técnico.</Text>
          <TouchableOpacity style={styles.modalButton} onPress={openEmailApp}>
            <Text style={styles.modalButtonText}>Contatar Suporte</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.closeButton} onPress={() => setModalVisible(false)}>
            <Text style={styles.closeButtonText}>Fechar</Text>
          </TouchableOpacity>
        </View>
      </Modal>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: 'fff',
    paddingHorizontal: 20,
  },
  inner: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  input: {
    width: '80%',
    height: 50,
    borderWidth: 1,
    borderColor: '#FF6347',
    borderRadius: 10,
    paddingHorizontal: 15,
    marginBottom: 15,
    backgroundColor: '#FFFFFF',
    color: '#333333',
  },
  buttonContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    marginVertical: 10,
  },
  button: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
    borderRadius: 13,
    marginVertical: 5,
    marginHorizontal: 5,
    width: 200,
  },
  buttonText: {
    marginLeft: 10,
    fontSize: 16,
  },
  loginButton: {
    backgroundColor: '#FF6347',
    padding: 10,
    borderRadius: 13,
    marginBottom: 20,
    width: 200,
  },
  loginButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  helpButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 10,
  },
  helpButtonText: {
    color: '#FF6347',
    marginLeft: 5,
  },
  logo: {
    width: 125,
    height: 185,
  },
});

export default LoginScreen;