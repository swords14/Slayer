import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, Image, TouchableOpacity, TextInput } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

const MusicLibraryScreen = ({ navigation }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const musicLibraries = [
    { id: 1, title: 'Library 1', description: 'Descrição da Biblioteca 1', imageUri: 'https://images.genius.com/318d7c1c46db985db9e93841ed062bfc.534x534x1.jpg' },
    { id: 2, title: 'Library 2', description: 'Descrição da Biblioteca 2', imageUri: 'https://cadernopop.com.br/wp-content/uploads/2021/11/Sub-Urban-1024x848.jpg' },
    { id: 3, title: 'Library 3', description: 'Descrição da Biblioteca 3', imageUri: 'https://i.ytimg.com/vi/lW9ep22YmlM/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLAjCc4Ys3MAucDblIKUAEwvJtfMwA' },
  ];

  const renderLibraryItem = ({ item }) => {
    if (!item.title.toLowerCase().includes(searchTerm.toLowerCase())) {
      return null;
    }
    return (
      <TouchableOpacity style={styles.libraryItem} onPress={() => navigation.navigate('LibraryDetail', { libraryId: item.id })}>
        <Image source={{ uri: item.imageUri }} style={styles.libraryItemImage} />
        <View style={styles.libraryItemTextContainer}>
          <Text style={styles.libraryItemTitle}>{item.title}</Text>
          <Text style={styles.libraryItemDescription}>{item.description}</Text>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <LinearGradient
      colors={['#4e4376', '#2b5876']}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={styles.container}>
      <Text style={styles.screenTitle}>Music Library</Text>
      <TextInput
        style={styles.searchInput}
        placeholder="Search music libraries"
        value={searchTerm}
        onChangeText={setSearchTerm}
      />
      <FlatList
        data={musicLibraries}
        keyExtractor={(item) => item.id.toString()}
        renderItem={renderLibraryItem}
        contentContainerStyle={styles.libraryList}
      />
    </LinearGradient>
  );
};


const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 40,
    paddingBottom: 30,
    justifyContent: 'center',
  },
  screenTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#fff',
    textAlign: 'center',
  },
  libraryList: {
    flexGrow: 1,
  },
  libraryItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 10,
    padding: 10,
  },
  libraryItemImage: {
    width: 100,
    height: 100,
    borderRadius: 10,
  },
  libraryItemTextContainer: {
    marginLeft: 10,
    flex: 1,
  },
  libraryItemTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
  },
  libraryItemDescription: {
    fontSize: 14,
    color: '#fff',
  },
  searchInput: {
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
    borderRadius: 10,
    padding: 10,
    marginBottom: 10,
  },
});

export default MusicLibraryScreen;